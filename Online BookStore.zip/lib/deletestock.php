<?php
include 'dbconnection.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM books WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<script>alert('Book deleted successfully!'); window.location.href='stock.php';</script>";
    } else {
        echo "<script>alert('Error deleting book: " . $conn->error . "'); window.location.href='stock.php';</script>";
    }

    $stmt->close();
}
$conn->close();
?>
