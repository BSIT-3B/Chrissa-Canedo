<?php
session_start();
include 'dbconnection.php';

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = trim($_POST['firstname']);
    $lastname = trim($_POST['lastname']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (empty($firstname) || empty($lastname) || empty($email) || empty($password)) {
        $error = "All fields are required.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("INSERT INTO users (firstname, lastname, email, password) VALUES (?, ?, ?, ?)");
        if (!$stmt) {
            die("Query preparation failed: " . $conn->error);
        }
        
        $stmt->bind_param("ssss", $firstname, $lastname, $email, $hashed_password);
        
        if ($stmt->execute()) {
            $success = "Registration successful! You can now <a href='login.php'>login</a>.";
        } else {
            $error = "Registration failed. Email may already be in use.";
        }

        $stmt->close();
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Page</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            display: flex;
            height: 100vh;
            justify-content: center;
            align-items: center;
            background: url('bgimagelogin.jpg') no-repeat center center/cover;
            overflow: hidden;
        }
        
        .container {
            display: flex;
            width: 900px;
            height: 600px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            background: #FFFBFB;
            overflow: hidden;
        }
        
        .background-image {
            background: url('loginimage.jpg') no-repeat center center/cover;
            width: 50%;
            position: relative;
        }
        
        .form-container {
            padding: 40px;
            width: 50%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 8px;
            transform: translateX(100px);
            opacity: 0;
            transition: transform 0.1 ease-out, opacity 0.1 ease-out;
        }
        
        body.loaded .form-container {
            transform: translateX(0);
            opacity: 1;
        }
        
        h1 {
            font-size: 28px;
            color: #444;
            margin-bottom: 10px;
        }
        
        label {
            font-weight: bold;
            margin-top: 10px;
        }
        
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 7px 0 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
			
        }
        
        button {
            background-color: #000066;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 4px;
            cursor: pointer;
            width: 106%;
            font-size: 16px;
        }
        
        button:hover {
            background-color: #00004d;
        }
        
        .error {
            color: red;
            margin-bottom: 10px;
        }
        
        .success {
            color: green;
            margin-bottom: 10px;
        }
		
		a {
            color: #000066;
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }
        


    </style>
</head>
<body>
    <div class="container">
        <div class="background-image"></div>
        <div class="form-container">
            <h1>Create an Account</h1>
            <?php 
                if (!empty($error)) { echo "<p class='error'>$error</p>"; }
                if (!empty($success)) { echo "<p class='success'>$success</p>"; }
            ?>
            <form action="register.php" method="POST">
                <label for="firstname">First Name</label>
                <input type="text" id="firstname" name="firstname" required>
                
                <label for="lastname">Last Name</label>
                <input type="text" id="lastname" name="lastname" required>
                
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
                
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                
                <button type="submit">Register</button>
            </form>
            <p>Already have an account? <a href="login.php">Login here</a></p>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            document.body.classList.add("loaded");
        });
    </script>
</body>
</html>
