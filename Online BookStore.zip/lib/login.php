<?php
session_start();
include 'dbconnection.php';

$error = ""; // Initialize error variable

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (empty($email) || empty($password)) {
        $error = "Please enter both email and password.";
    } else {
        $stmt = $conn->prepare("SELECT id, password FROM users WHERE email = ?");
        if (!$stmt) {
            die("Query preparation failed: " . $conn->error);
        }

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($id, $hashed_password);
            $stmt->fetch();

            if (password_verify($password, $hashed_password)) {
                $_SESSION['user_id'] = $id;
                $_SESSION['email'] = $email;
                header("Location: dashboard.php");
                exit();
            } else {
                $error = "Invalid email or password.";
            }
        } else {
            $error = "Invalid email or password.";
        }

        $stmt->close();
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            display: flex;
            height: 100vh;
            justify-content: center;
            align-items: center;
            background: url('bgimagelogin.jpg') no-repeat center center/cover;
            overflow: hidden;
            opacity: 0;
            transition: opacity 1s ease-in-out;
        }

        .container {
            display: flex;
            width: 800px;
            height: 500px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            background: #FFFBFB;
            overflow: hidden;
            opacity: 0;
            transform: scale(0.9);
            transition: opacity 1s ease-in-out, transform 0.7s ease-in-out;
        }

        .background-image {
            background: url('loginimage.jpg') no-repeat center center/cover;
            width: 50%;
            position: relative;
            opacity: 0;
            transition: opacity 1.2s ease-in-out;
        }

        .form-container {
            padding: 40px;
            width: 50%;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            border-radius: 8px;
            opacity: 0;
            transition: opacity 1s ease-in-out;
        }

        body.loaded {
            opacity: 1;
        }

        body.loaded .container,
        body.loaded .form-container,
        body.loaded .background-image {
            opacity: 1;
            transform: scale(1);
        }

        h1 {
            font-size: 28px;
            color: #444;
            margin-bottom: 15px;
        }

        label {
            font-weight: bold;
            margin-top: 10px;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 5px 0 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        .remember {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        button {
            background-color: #000066;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
        }

        button:hover {
            background-color: #00004d;
        }

        p {
            margin-top: 15px;
            font-size: 14px;
        }

        .error {
            color: red;
            margin-bottom: 10px;
        }

        a {
            color: #000066;
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="background-image"></div>
        <div class="form-container">
            <h1>Welcome Back!</h1>
            <?php if (!empty($error)) { echo "<p class='error'>$error</p>"; } ?>
            <form action="login.php" method="POST">
                <label for="email">Email</label>
                <input type="text" id="email" name="email" required>
                
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                
                <div class="remember">
                    <input type="checkbox" id="remember" name="remember">
                    <label for="remember">Remember me</label>
                </div>
                
                <button type="submit">Login</button>
            </form>
            <p>Don’t have an account? <a href="register.php">Create One</a></p>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            document.body.classList.add("loaded");
        });
    </script>
</body>
</html>