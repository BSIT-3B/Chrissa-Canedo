<?php
include 'dbconnection.php';

$selectedGenre = isset($_GET['genre']) ? $_GET['genre'] : '';
$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';
$books = [];

if ($searchTerm !== '') {
    $searchQuery = "%{$searchTerm}%";
    $stmt = $conn->prepare("SELECT title, author FROM books WHERE title LIKE ? OR author LIKE ?");
    $stmt->bind_param("ss", $searchQuery, $searchQuery);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $books[] = $row;
    }
} elseif ($selectedGenre) {
    $stmt = $conn->prepare("SELECT title, author FROM books WHERE genre = ?");
    $stmt->bind_param("s", $selectedGenre);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $books[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Dashboard</title>
    <style>
        html, body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            overflow-x: hidden;
        }

        .sidebar {
            background-color: #d9e1f2;
            width: 250px;
            padding: 20px;
            height: 100vh;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
        }

        .sidebar h1 {
            font-size: 40px;
            margin-bottom: 20px;
            color: #333;
        }

        .sidebar a {
            display: block;
            padding: 10px 0;
            color: #333;
            text-decoration: none;
            font-size: 20px;
            margin: 20px 0;
        }

        .sidebar a:hover {
            background-color: #060270;
            border-radius: 10px;
            padding: 10px;
            color: #ffffff;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            background-color: #fff;
            min-height: 100vh;
            box-sizing: border-box;
        }

        .topbar {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 10px;
            background-color: #eef2ff;
            border-radius: 5px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .search-box {
            display: flex;
            align-items: center;
            background-color: white;
            padding: 10px;
            border-radius: 5px;
            width: 100%;
            max-width: 700px;
			margin-left: 850px
        }

        .search-box input {
            border: none;
            outline: none;
            padding: 15px;
            width: 100%;
            font-size: 16px;
			
        }

        .search-box button {
            padding: 10px 20px;
            background-color: #060270;
            color: white;
            border: none;
            border-radius: 5px;
            margin-left: 10px;
            cursor: pointer;
        }

        .category-section {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin-bottom: 30px;
        }

        .category {
            background-color: #fff;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            width: 120px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out;
        }

        .category:hover {
            transform: scale(1.1);
        }

        .category img {
            width: 100px;
            height: 100px;
            margin-bottom: 10px;
        }

        table {
            margin: 20px auto;
            width: 90%;
            border-collapse: collapse;
        }

        table th, table td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }

        table th {
            background-color: #d9e1f2;
        }

        .carousel {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
            margin: 30px 0;
        }

        .carousel img {
            width: 550px;
			height: 400px;
            height: auto;
            border-radius: 8px;
        }

        .trending-banner {
            background-color: #060270;
            color: white;
            border-radius: 8px;
            padding: 30px 20px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }

        .trending-banner h2 {
            font-size: 24px;
            margin: 0;
        }

        .view-books-button {
            background-color: #302BB5;
            color: white;
            border: none;
            padding: 12px 20px;
            cursor: pointer;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }

        @media (max-width: 768px) {
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }

            .main-content {
                margin-left: 0;
            }

            .trending-banner {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .view-books-button {
                align-self: flex-end;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h1>Dashboard</h1>
        <a href="index.php">Home</a>
        <a href="viewbooks.php">Book List</a>
        <a href="stock.php">Stock Tracking</a>
        <a href="addbooks.php">Add Books</a>
        <a href="logout.php">Logout</a>
        <form action="logout.php" method="POST">
            <button type="submit" style="
                width: 100%;
                background: none;
                border: none;
                color: #333;
                font-size: 20px;
                padding: 10px;
                cursor: pointer;
                text-align: left;
            " onmouseover="this.style.backgroundColor='#060270'; this.style.color='#fff';" 
            onmouseout="this.style.backgroundColor=''; this.style.color='#333';">
            </button>
        </form>
    </div>

    <div class="main-content">
        <div class="topbar">
            <form class="search-box" method="GET" action="">
                <input type="text" name="search" placeholder="Search by title or author..." value="<?= htmlspecialchars($searchTerm) ?>">
                <button type="submit">Search</button>
            </form>
        </div>

        <h2 style="text-align:center;">Category</h2>
        <div class="category-section">
            <a href="?genre=Cooking"><div class="category"><img src="cooking-icon.png"><p>Cooking</p></div></a>
            <a href="?genre=Encyclopedia"><div class="category"><img src="encyclopedia-icon.png"><p>Encyclopedia</p></div></a>
            <a href="?genre=Comedy"><div class="category"><img src="comedy-icon.png"><p>Comedy</p></div></a>
            <a href="?genre=Horror"><div class="category"><img src="horror-icon.png"><p>Horror</p></div></a>
            <a href="?genre=Myths"><div class="category"><img src="myths-icon.png"><p>Myths</p></div></a>
            <a href="?genre=Romance"><div class="category"><img src="Romance-icon.png"><p>Romance</p></div></a>
        </div>

        <?php if ($searchTerm !== ''): ?>
            <h3 style="text-align: center;">Search Results for: "<?= htmlspecialchars($searchTerm) ?>"</h3>
        <?php elseif ($selectedGenre): ?>
            <h3 style="text-align: center;">Books in Genre: <?= htmlspecialchars($selectedGenre) ?></h3>
        <?php endif; ?>

        <?php if (($selectedGenre || $searchTerm !== '') && count($books) > 0): ?>
            <table>
                <thead>
                    <tr><th>Title</th><th>Author</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($books as $book): ?>
                        <tr>
                            <td><?= htmlspecialchars($book['title']) ?></td>
                            <td><?= htmlspecialchars($book['author']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php elseif ($selectedGenre || $searchTerm !== ''): ?>
            <p style="text-align: center; color: red;">No books found.</p>
        <?php endif; ?>

        <div class="carousel">
            <img src="image1.jpg" alt="Library Image">
            <img src="image3.jpg" alt="Library Image">
            <img src="image5.jpg" alt="Library Image">
            <img src="image6.jpg" alt="Library Image">
        </div>

        </div>
    </div>
</body>
</html>
