<?php
include 'dbconnection.php';

$books = [];
$sql = "SELECT id, title, price, quantity FROM books";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $books[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Stock Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .main-content {
            padding: 30px;
            max-width: 1000px;
            margin: auto;
            background-color: #fff;
            min-height: 100vh;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .button-container {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 20px;
        }

        .button-container a {
            padding: 10px 20px;
            text-decoration: none;
            background-color: #060270;
            color: white;
            border-radius: 5px;
            font-size: 16px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th, table td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }

        table th {
            background-color: #d9e1f2;
        }

        .action-buttons a {
            margin: 0 5px;
            padding: 6px 12px;
            background-color: #302BB5;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
        }

        .action-buttons a.delete {
            background-color: #cc0000;
        }

        .action-buttons a:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
    <div class="main-content">
        <h2>Stock Management</h2>

        <div class="button-container">
            <a href="dashboard.php">← Back to Dashboard</a>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($books) > 0): ?>
                    <?php foreach ($books as $book): ?>
                        <tr>
                            <td><?= htmlspecialchars($book['title']) ?></td>
                            <td>₱<?= number_format($book['price'], 2) ?></td>
                            <td><?= htmlspecialchars($book['quantity']) ?></td>
                            <td class="action-buttons">
                                <a href="editstock.php?id=<?= $book['id'] ?>">Edit</a>
                                <a href="deletestock.php?id=<?= $book['id'] ?>" class="delete" onclick="return confirm('Are you sure you want to delete this book?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="4">No stock records found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
