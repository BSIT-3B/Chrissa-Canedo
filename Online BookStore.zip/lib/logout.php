<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .popup-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.3);
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .popup {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            width: 300px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .popup img {
            width: 80px;
            border-radius: 50%;
            margin-bottom: 10px;
        }
        .popup-buttons {
            margin-top: 20px;
        }
        .popup-buttons button {
            padding: 10px 20px;
            margin: 5px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .logout-btn {
            background-color: blue;
            color: white;
        }
        .cancel-btn {
            background-color: red;
            color: white;
        }
    </style>
</head>
<body>
    <div class="popup-container" id="popupContainer">
        <div class="popup">
            <img src="https://static.vecteezy.com/system/resources/previews/014/194/216/original/avatar-icon-human-a-person-s-badge-social-media-profile-symbol-the-symbol-of-a-person-vector.jpg" alt="User Avatar">
            <p>Are you sure you want to log out?</p>
            <div class="popup-buttons">
                <button class="logout-btn" onclick="logout()">Log out</button>
                <button class="cancel-btn" onclick="redirectToDashboard()">Cancel</button>
            </div>
        </div>
    </div>

    <script>
        function redirectToDashboard() {
            window.location.href = "dashboard.php"; // Change to your actual dashboard URL
        }

        function logout() {
            // Clear session storage or local storage
            sessionStorage.clear();
            localStorage.clear();

            // Redirect to index.php without making another page
            window.location.href = "index.php";
        }
    </script>
</body>
</html>
