<!DOCTYPE html>
<html>
<head>
    <title>Library Management System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Hack', monospace;
        }

        body {
            background-image: url('homepage.jpg');
            background-size: cover;
            background-position: center;
            height: 100vh;
            overflow: hidden;
        }

        .overlay {
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 50px;
            transition: transform 1s ease-in-out, opacity 1s ease-in-out;
        }

        @keyframes fadeUp {
            from {
                opacity: 0;
                transform: translateY(50px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .title {
            color: white;
            font-size: 105px;
            font-weight: bold;
            line-height: 1.2;
            margin-top: -150px;
            margin-left: 100px;
            font-family: Arial, sans-serif;
            opacity: 0;
            animation: fadeUp 1s ease-out forwards;
        }

        .description {
            color: white;
            font-size: 20px;
            max-width: 900px;
            margin-top: 10px;
            margin-left: 100px;
            font-family: 'Lato', sans-serif;
            opacity: 0;
            animation: fadeUp 1s ease-out 0.5s forwards;
        }

        .get-started-btn {
            margin-top: 30px;
            margin-left: 100px;
            padding: 15px 10px;
            background-color: #060270;
            color: white;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.5s;
            text-decoration: none;
            font-family: Arial, sans-serif, bold;
            width: 200px; 
            text-align: center;
            opacity: 0;
            animation: fadeUp 1s ease-out 1s forwards;
        }

        .get-started-btn:hover {
            background-color: transparent;
            color: #ffffff;
            border: 2px solid #ffffff;
            transform: scale(1.05);
        }

        /* Fade out and slide effect */
        .fade-out {
            transform: translateY(-50px);
            opacity: 0;
            transition: transform 1s ease-in-out, opacity 1s ease-in-out;
        }
    </style>
</head>
<body>
    <div class="overlay" id="overlay">
        <div class="title">
            Library<br>Management System
        </div>
        <p class="description">
            Our Online Library Management System is built to provide comfort and accessibility 
            for all users. Whether you are searching for academic books, novels, or references, 
            our system ensures quick and easy access to all available resources. 
            Discover, manage, and enjoy your reading journey with us!
        </p>

        <button class="get-started-btn" onclick="startAnimation()">Get Started</button>
    </div>

    <script>
        function startAnimation() {
            let overlay = document.getElementById("overlay");
            overlay.classList.add("fade-out");

            setTimeout(() => {
                window.location.href = "login.php"; // Redirect to login page
            }, 100); // Wait for animation to finish
        }
    </script>
</body>
</html>


