<?php
include 'dbconnection.php';

if (!isset($_GET['id'])) {
    header("Location: stock.php");
    exit();
}

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $price = $_POST['price'];
    $quantity = $_POST['quantity'];

    $stmt = $conn->prepare("UPDATE books SET price=?, quantity=? WHERE id=?");
    $stmt->bind_param("dii", $price, $quantity, $id);
    $stmt->execute();

    header("Location: stock.php");
    exit();
}

$stmt = $conn->prepare("SELECT * FROM books WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$book = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Book Stock</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 30px;
            background-color: #f4f4f4;
        }
        form {
            background: #fff;
            padding: 25px;
            max-width: 500px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        input {
            width: 95%;
            padding: 12px;
            margin: 10px 0;
            font-size: 16px;
        }
        input[readonly] {
            background-color: #e9e9e9;
        }
        button {
            padding: 10px 20px;
            background: #060270;
            color: white;
            border: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }
        a {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            color: #060270;
        }
    </style>
</head>
<body>
    <h2 style="text-align: center;">Edit Book Stock</h2>
    <form method="POST" action="">
        <label>Title:</label>
        <input type="text" value="<?= htmlspecialchars($book['title']) ?>" readonly>

        <label>Price (₱):</label>
        <input type="number" name="price" step="0.01" value="<?= $book['price'] ?>" required>

        <label>Quantity:</label>
        <input type="number" name="quantity" value="<?= $book['quantity'] ?>" required>

        <button type="submit">Update Stock</button><br>
        <a href="stock.php">← Back to Stock</a>
    </form>
</body>
</html>
