<?php
session_start();

// Handle theme change
if (isset($_POST['theme'])) {
    setcookie('theme', $_POST['theme'], time() + (86400 * 30), "/");
    $_COOKIE['theme'] = $_POST['theme'];
}

// Handle logout
if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}

// Handle forget theme
if (isset($_POST['forget_theme'])) {
    setcookie('theme', '', time() - 3600, "/");
    unset($_COOKIE['theme']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Settings</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f4f8;
            color: #333;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: white;
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #4a90e2;
        }
        label, select, button {
            display: block;
            width: 100%;
            margin-top: 10px;
        }
        button {
            padding: 10px;
            background: #4a90e2;
            border: none;
            color: white;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 15px;
        }
        button:hover {
            background: #357ab7;
        }
        .data-section {
            background: #fafafa;
            padding: 15px;
            border-radius: 10px;
            margin-top: 20px;
            font-size: 0.95em;
        }
        a {
            display: block;
            margin-top: 25px;
            text-align: center;
            color: #555;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>⚙️ Settings</h1>

        <form method="post">
            <label for="theme">🎨 Choose your vibe (Theme):</label>
            <select name="theme" id="theme">
                <option value="light" <?= (isset($_COOKIE['theme']) && $_COOKIE['theme'] == 'light') ? 'selected' : '' ?>>Light</option>
                <option value="dark" <?= (isset($_COOKIE['theme']) && $_COOKIE['theme'] == 'dark') ? 'selected' : '' ?>>Dark</option>
            </select>
            <button type="submit"> Save Theme</button>
        </form>

        <form method="post">
            <button type="submit" name="forget_theme"> Forget Theme</button>
        </form>

        <form method="post">
            <button type="submit" name="logout"> Log Out</button>
        </form>

        <div class="data-section">
            <h3> Session Data</h3>
            <pre><?php print_r($_SESSION); ?></pre>

            <h3> Cookie Data</h3>
            <pre><?php print_r($_COOKIE); ?></pre>
        </div>

        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
