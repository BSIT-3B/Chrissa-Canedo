<?php
session_start();

if (!isset($_SESSION['studentName']) || !isset($_SESSION['studentId'])) {
    header('Location: login.php');
    exit;
}

$studentName = $_SESSION['studentName'];
$studentId = $_SESSION['studentId'];
$courses = $_SESSION['courses'] ?? ['Math 101', 'History 201', 'Science 301']; // Sample fallback

$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : 'light';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student Dashboard</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: <?= $theme === 'dark' ? '#333' : '#ffffff' ?>;
            color: <?= $theme === 'dark' ? '#fff' : '#000' ?>;
        }

        .header {
            background-color: #3B82F6;
            color: white;
            padding: 40px 30px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
        }

        .profile-info {
            display: flex;
            align-items: center;
        }

        .avatar {
            width: 150px;
            height: 150px;
            background-image: url('png.png');
            background-size: cover;
            background-position: center;
            border-radius: 50%;
            margin-right: 20px;
            border: 6px solid white;
        }

        .welcome-text h1 {
            margin: 0;
            font-size: 32px;
            font-weight: bold;
        }

        .welcome-text h2 {
            margin: 5px 0 0;
            font-size: 24px;
        }

        .welcome-text p {
            margin: 8px 0 0;
        }

        .top-buttons {
            display: flex;
            gap: 10px;
        }

        .top-buttons button {
            padding: 10px 16px;
            font-size: 14px;
            border: none;
            border-radius: 10px;
            background-color: #f1f1ff;
            cursor: pointer;
        }

        .course-section {
            padding: 20px 40px;
        }

        .course-title {
            text-align: center;
            font-weight: bold;
            font-size: 20px;
            padding: 15px;
            background-color: #f1f1ff;
            border-radius: 12px;
            margin-bottom: 20px;
        }

        .course-list {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            justify-content: start;
        }

        .course-card {
            width: 120px;
            height: 130px;
            border-radius: 15px;
            background-color: #f0f0ff;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 10px;
            text-align: center;
        }

        .course-card img {
            width: 40px;
            height: 40px;
            margin-bottom: 10px;
        }

        /* ✅ DARK MODE TEXT OVERRIDE FOR COURSE SECTION */
        body.dark-theme .course-title,
        body.dark-theme .course-card,
        body.dark-theme .course-card div {
            color: black;
        }
    </style>
</head>
<body class="<?= $theme ?>-theme">
    <div class="header">
        <div class="profile-info">
            <div class="avatar"></div>
            <div class="welcome-text">
                <h1>Welcome</h1>
                <h2><?= htmlspecialchars($studentName) ?></h2>
                <p>ID: <?= htmlspecialchars($studentId) ?></p>
            </div>
        </div>
        <div class="top-buttons">
            <form action="setting.php" method="GET">
                <button type="submit">Settings</button>
            </form>
            <form action="logout.php" method="POST">
                <button type="submit">Logout</button>
            </form>
        </div>
    </div>

    <div class="course-section">
        <div class="course-title">Your Enrolled Courses</div>
        <div class="course-list">
            <?php if (empty($courses)): ?>
                <p>No courses enrolled yet.</p>
            <?php else: ?>
                <?php foreach ($courses as $course): ?>
                    <div class="course-card">
                        <img src="cours.png" alt="Course Icon">
                        <div><?= htmlspecialchars($course) ?></div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
