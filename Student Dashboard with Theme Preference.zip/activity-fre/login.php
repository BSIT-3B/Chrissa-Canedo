<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['theme'])) {
    setcookie('theme', $_POST['theme'], time() + (86400 * 30), "/");
    header("Refresh:0");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name']) && !isset($_POST['theme'])) {
    $studentName = $_POST['name'];
    $studentId = rand(1000, 9999);

    $_SESSION['studentName'] = $studentName;
    $_SESSION['studentId'] = $studentId;
    $_SESSION['courses'] = ['Math 101', 'History 201', 'Science 301'];

    header('Location: dashboard.php');
    exit;
}

$theme = isset($_COOKIE['theme']) ? $_COOKIE['theme'] : 'light';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login Split UI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', sans-serif;
            height: 100vh;
            display: flex;
        }

        .left, .right {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .left {
            background-color: #fff;
            flex-direction: column;
            padding: 40px;
        }

        .right {
            background: linear-gradient(135deg, #5d3eff, #895fff);
            position: relative;
            overflow: hidden;
        }

        .login-box {
            width: 100%;
            max-width: 350px;
            text-align: center;
        }

        .login-box h1 { margin-bottom: 10px; font-weight: 700; }
        .login-box p { color: #888; font-size: 14px; margin-bottom: 25px; }

        .input-group {
            position: relative;
            margin-bottom: 15px;
        }

        .input-group input {
            width: 100%;
            padding: 12px 40px;
            border: none;
            border-radius: 12px;
            background-color: #f0efff;
            font-size: 16px;
        }

        .input-group i {
            position: absolute;
            top: 50%;
            left: 12px;
            transform: translateY(-50%);
            color: #888;
        }

        .login-box button {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 12px;
            background-color: #f0efff;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
        }

        .theme-select-title {
            margin-top: 25px;
            font-weight: 500;
            font-size: 15px;
        }

        .theme-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 15px;
        }

        .theme-buttons button {
            flex: 1;
            padding: 15px;
            border: none;
            border-radius: 12px;
            background-color: #f0efff;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
        }

        .theme-buttons i {
            font-size: 24px;
            display: block;
            margin-bottom: 5px;
        }

        .slider-container {
            max-width: 750px;
            width: 100%;
            height: 80%;
            position: relative;
            border-radius: 30px;
            overflow: hidden;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        }

        .slide {
            position: absolute;
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0;
            transition: opacity 1s ease-in-out;
        }

        .slide.active {
            opacity: 1;
            z-index: 2;
        }

        .icon-overlay {
            position: absolute;
            bottom: 15px;
            left: 15px;
            background: white;
            border-radius: 50%;
            padding: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            z-index: 3;
        }

        .carousel-dots {
            position: absolute;
            bottom: 25px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 10px;
            z-index: 3;
        }

        .carousel-dots span {
            width: 12px;
            height: 12px;
            background-color: rgba(255, 255, 255, 0.5);
            border-radius: 50%;
            cursor: pointer;
        }

        .carousel-dots .active {
            background-color: #fff;
        }

        .selected-theme {
            margin-top: 25px;
            font-weight: bold;
            text-align: center;
        }

        .selected-theme div {
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #f0efff;
            border-radius: 12px;
            display: inline-block;
            margin-left: 15px;
        }
    </style>
</head>
<body class="<?= $theme ?>-theme">
    <div class="left">
        <div class="login-box">
            <h1>LOGIN</h1>
            <p>Log in with your student account to continue.</p>

           
            <form action="login.php" method="POST">
                <div class="input-group">
                    <i class="fa fa-user"></i>
                    <input type="text" name="name" placeholder="Enter your name" required>
                </div>
                <button type="submit">Login</button>
            </form>

            
            <form action="login.php" method="POST">
                <div class="theme-select-title">Select Theme</div>
                <div class="theme-buttons">
                    <button type="submit" name="theme" value="light">
                        <i class="fa-regular fa-moon"></i>Light
                    </button>
                    <button type="submit" name="theme" value="dark">
                        <i class="fa-solid fa-moon"></i>Dark
                    </button>
                </div>
            </form>

           
            <div class="selected-theme">
                Selected Theme
                <div><?= ucfirst($theme) ?></div>
            </div>
        </div>
    </div>

    <div class="right">
        <div class="slider-container">
            <img src="img1.jpg" class="slide active" alt="Slide 1">
            <img src="img2.jpg" class="slide" alt="Slide 2">
            <img src="img3.jpg" class="slide" alt="Slide 3">

            <div class="icon-overlay">
                <i class="fas fa-bolt" style="color: #ffcc00;"></i>
            </div>

            <div class="carousel-dots">
                <span onclick="showSlide(0)" class="dot active"></span>
                <span onclick="showSlide(1)" class="dot"></span>
                <span onclick="showSlide(2)" class="dot"></span>
            </div>
        </div>
    </div>

    <script>
        let currentSlide = 0;
        const slides = document.querySelectorAll('.slide');
        const dots = document.querySelectorAll('.dot');

        function showSlide(index) {
            slides.forEach((slide, i) => {
                slide.classList.remove('active');
                dots[i].classList.remove('active');
            });

            slides[index].classList.add('active');
            dots[index].classList.add('active');
            currentSlide = index;
        }

        function nextSlide() {
            currentSlide = (currentSlide + 1) % slides.length;
            showSlide(currentSlide);
        }

        setInterval(nextSlide, 3000); 
    </script>
</body>
</html>
