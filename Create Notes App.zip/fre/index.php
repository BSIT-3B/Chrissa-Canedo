<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Notes App</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #d6eaff; /* Light blue background */
            color: #333;
            text-align: center;
        }
        h1 {
            color: #1d6fa5; /* Stitch's blue color */
            font-size: 2.5em;
        }
        h2 {
            color: #ff7f50; /* Tropical coral color */
        }
        .container {
            display: flex;
            justify-content: center;
            gap: 40px; /* Space between the two forms */
            margin-top: 30px;
        }
        .form-container {
            background-color: #fff;
            border-radius: 15px;
            padding: 30px;
            width: 350px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border: 2px solid #1d6fa5; /* Stitch's blue color */
        }
        input[type="text"], textarea {
            width: 90%;
            padding: 12px;
            margin: 12px 0;
            border: 2px solid #1d6fa5; /* Stitch's blue color */
            border-radius: 8px;
            font-size: 1em;
        }
        button {
            background-color: #ff7f50; /* Tropical coral color */
            color: white;
            border: none;
            padding: 12px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.1em;
        }
        button:hover {
            background-color: #ff5a30; /* Lighter coral shade */
        }
        img {
            width: 200px; /* Adjust size */
            margin: 20px 0;
            border-radius: 10px;
        }
        .note-text {
            font-style: italic;
            color: #2e2e2e;
        }
    </style>
</head>
<body>
    <h1>Welcome to the Personal Notes App</h1>
    <img src="stitch.png" alt="Stitch"> <!-- Replace with a valid image URL -->

    <div class="container">
        <div class="form-container">
            <h2>Write a Note</h2>
            <form method="post">
                Username: <input type="text" name="username" required><br><br>
                Note: <textarea name="note" required></textarea><br><br>
                <button type="submit" name="save_note">Save Note</button>
            </form>
        </div>

        <div class="form-container">
            <h2>View Your Notes</h2>
            <form method="post">
                Username: <input type="text" name="view_username" required><br><br>
                <button type="submit" name="view_notes">View Notes</button>
            </form>
        </div>
    </div>

    <?php
    $file = "notes.txt";  // File where notes are saved

    // Handle saving a note
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save_note'])) {
        $username = trim($_POST['username']);
        $note = trim($_POST['note']);
        
        if (!empty($username) && !empty($note)) {
            $entry = "$username|" . str_replace("\n", " ", $note) . "\n";
            file_put_contents($file, $entry, FILE_APPEND);
            echo "<p>Note saved successfully!</p>";
        } else {
            echo "<p>Please enter both username and note.</p>";
        }
    }

    // Handle viewing notes
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['view_notes'])) {
        $username = trim($_POST['view_username']);
        if (!empty($username)) {
            echo "<h3>Your Notes:</h3>";
            if (file_exists($file)) {
                $notes = file($file, FILE_IGNORE_NEW_LINES);
                $found = false;
                foreach ($notes as $line) {
                    list($storedUser , $storedNote) = explode("|", $line, 2);
                    if ($storedUser === $username) {
                        echo "<p><strong>$storedUser :</strong> <span class='note-text'>" . htmlspecialchars($storedNote) . "</span></p>";
                        $found = true;
                    }
                }
                if (!$found) echo "<p>No notes found for this username.</p>";
            } else {
                echo "<p>No notes available.</p>";
            }
        } else {
            echo "<p>Please enter a username to view notes.</p>";
        }
    }
    ?>
</body>
</html>
