<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $weight = isset($_POST['weight']) ? floatval($_POST['weight']) : 0;
    $height = isset($_POST['height']) ? floatval($_POST['height']) / 100 : 0; // Convert cm to meters
    $bmi = 0;
    $category = "";

    if ($weight > 0 && $height > 0) {
        $bmi = $weight / ($height * $height);
        $bmi = round($bmi, 2);

        if ($bmi < 18.5) {
            $category = "Underweight";
        } elseif ($bmi >= 18.5 && $bmi <= 24.9) {
            $category = "Normal weight";
        } elseif ($bmi >= 25 && $bmi <= 29.9) {
            $category = "Overweight";
        } else {
            $category = "Obese";
        }
    } else {
        $category = "Invalid input. Please enter valid values.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>BMI Calculator</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script>
        function showResult() {
            document.getElementById("bmiResult").style.display = "block";
        }
    </script>
</head>
<body>
    <div class="bmi-container">
        <h1>BMI CALCULATOR</h1>
        <div class="gender-selection">
            <label>
                <input type="radio" name="gender" value="female" checked>
                <span class="female">♀</span>
            </label>
            <label>
                <input type="radio" name="gender" value="male">
                <span class="male">♂</span>
            </label>
        </div>
        <form method="post" action="" onsubmit="showResult(); return false;">
            <div class="input-group">
                <label for="height">Height (cm)</label>
                <input type="number" step="0.1" name="height" required>
            </div>
            <div class="input-group">
                <label for="weight">Weight (kg)</label>
                <input type="number" step="0.1" name="weight" required>
            </div>
            <button type="submit" class="calculate-btn">Calculate your BMI!</button>
        </form>
        <div id="bmiResult" class="result-popup" style="display:none;">
            <h3>Your BMI: <?php echo $bmi; ?></h3>
            <h3>Category: <?php echo $category; ?></h3>
        </div>
    </div>
</body>
</html>

<style>
    body {
        font-family: Arial, sans-serif;
        text-align: center;
        background: #f4f4f4;
    }
    .bmi-container {
        width: 350px;
        margin: auto;
        padding: 20px;
        background: white;
        box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        border-radius: 10px;
    }
    h1 {
        background: #5d00b3;
        color: white;
        padding: 10px;
        border-radius: 10px 10px 0 0;
    }
    .gender-selection {
        display: flex;
        justify-content: center;
        gap: 20px;
        margin: 15px 0;
    }
    .gender-selection label {
        cursor: pointer;
        font-size: 24px;
        color: gray;
    }
    .gender-selection input:checked + span {
        color: #5d00b3;
    }
    .input-group {
        margin: 10px 0;
    }
    .calculate-btn {
        background: #5d00b3;
        color: white;
        padding: 10px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .result-popup {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0px 0px 10px rgba(0,0,0,0.2);
    }
</style>