<?php
session_start();

$host = "localhost";
$user = "root";
$pass = "";
$db = "assignment_portal";

// Create connection
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

// Check if there's a message in session
if (isset($_SESSION['upload_message'])) {
    $message = $_SESSION['upload_message'];
    unset($_SESSION['upload_message']); // Clear message after showing
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentName = $_POST['student_name'];
    $subject = $_POST['subject'];
    $file = $_FILES['assignment_file'];

    $allowedTypes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    $maxFileSize = 10 * 1024 * 1024; // 10MB

    if (!in_array($file['type'], $allowedTypes)) {
        $_SESSION['upload_message'] = "<div class='msg error'>❌ Invalid file type.</div>";
    } elseif ($file['size'] > $maxFileSize) {
        $_SESSION['upload_message'] = "<div class='msg error'>❌ File too large.</div>";
    } else {
        $uploadDir = "uploads/";
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $newFileName = time() . "_" . basename($file['name']);
        $targetFile = $uploadDir . $newFileName;

        if (move_uploaded_file($file["tmp_name"], $targetFile)) {
            $stmt = $conn->prepare("INSERT INTO submissions (student_name, subject, file_name, file_path, submitted_at) VALUES (?, ?, ?, ?, NOW())");
            $stmt->bind_param("ssss", $studentName, $subject, $file['name'], $targetFile);
            $stmt->execute();

            $_SESSION['upload_message'] = "<div class='msg success'>✅ Assignment uploaded successfully!</div>";
        } else {
            $_SESSION['upload_message'] = "<div class='msg error'>❌ Error uploading file.</div>";
        }
    }

    // Redirect to avoid resubmission
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Assignment Upload</title>
    <style>
        body {
            background-color: #f2f6fc;
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .upload-container {
            background-color: #fff;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            width: 400px;
        }

        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }

        label {
            font-weight: 600;
            display: block;
            margin-top: 15px;
        }

        input[type="text"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #ccc;
            margin-top: 5px;
            font-size: 14px;
        }

        input[type="submit"] {
            margin-top: 25px;
            width: 100%;
            background-color: #007bff;
            color: white;
            border: none;
            padding: 12px;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .msg {
            padding: 12px;
            border-radius: 6px;
            text-align: center;
            margin-bottom: 15px;
            font-weight: 600;
        }

        .msg.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .msg.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>

<div class="upload-container">
    <h2>Assignment Submission</h2>

    <?php if (!empty($message)) echo $message; ?>

    <form method="POST" enctype="multipart/form-data">
        <label>Student Name:</label>
        <input type="text" name="student_name" required>

        <label>Subject:</label>
        <input type="text" name="subject" required>

        <label>Upload File:</label>
        <input type="file" name="assignment_file" required>

        <input type="submit" name="submit" value="Upload Assignment">
    </form>
</div>

</body>
</html>
