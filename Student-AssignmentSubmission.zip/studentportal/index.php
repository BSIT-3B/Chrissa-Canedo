<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>SubmiTrack Portal</title>
  <style>
    body, html {
      height: 100%;
      margin: 0;
      font-family: Arial, sans-serif;
    }

    body {
      background-image: url('landing.jpg');
      background-size: cover;
      background-position: center;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .upload-btn {
      padding: 15px 30px;
      font-size: 18px;
      background-color: #00579d;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      box-shadow: 0 4px 6px rgba(0,0,0,0.2);
      transition: background-color 0.3s;
	  margin-top: 350px;
	  margin-left: 800px;
    }

    .upload-btn:hover {
      background-color: #003f70;
    }
  </style>
</head>
<body>

  <form action="upload.php">
    <button class="upload-btn" type="submit">Upload Assignment</button>
  </form>

</body>
</html>
