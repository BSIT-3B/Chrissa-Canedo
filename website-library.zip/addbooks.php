<?php
include 'dbconnection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $author = $_POST['author'];
    $genre = $_POST['genre'];
    $year_published = $_POST['year_published'];

    $stmt = $conn->prepare("INSERT INTO books (title, author, genre, year_published) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssi", $title, $author, $genre, $year_published);

    if ($stmt->execute()) {
        echo "<script>alert('Book added successfully!'); window.location.href='viewbooks.php';</script>";
        exit();
    } else {
        echo "<script>alert('Error adding book: " . $conn->error . "');</script>";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add Book</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
			background-image: url('addnewbooks.jpg');
            background-size: 900px;
            background-position: center;
			background-color: #FBF8F8
        }
        .container {
            width: 40%;
            background: white;
            padding: 20px;
            margin: 50px auto;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
			margin-top: 200px;
        }
        input, button {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .submit-btn {
            background-color: #040241;
            color: white;
            cursor: pointer;
            border: none;
			
        .submit-btn:hover {
            background-color: #0901F0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add New Book</h2>
        <form method="POST">
            <input type="text" name="title" placeholder="Book Title" required>
            <input type="text" name="author" placeholder="Author" required>
            <input type="text" name="genre" placeholder="Genre" required>
            <input type="number" name="year_published" placeholder="Year Published" required>
            <button type="submit" class="submit-btn">Add Book</button>
        </form>
        <a href="viewbooks.php">Back to Book List</a>
    </div>
</body>
</html>
