<!DOCTYPE html>
<html>
<head>
    <title>Edit Book</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 20px;
            text-align: center;
        }
        form {
            background: white;
            padding: 20px;
            max-width: 500px;
            margin: auto;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        input[type="text"], input[type="number"] {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .btn-container {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 10px;
        }
        .update-btn, .cancel-btn {
            padding: 10px 15px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 14px;
            width: 40%;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            color: white;
        }
        .update-btn {
            background-color: #007BFF;
        }
        .update-btn:hover {
            background-color: #0056b3;
        }
        .cancel-btn {
            background-color: #dc3545;
        }
        .cancel-btn:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <?php
    include 'dbconnection.php';
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $result = $conn->query("SELECT * FROM books WHERE id=$id");
        $book = $result->fetch_assoc();
    }
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $title = $_POST['title'];
        $author = $_POST['author'];
        $genre = $_POST['genre'];
        $year_published = $_POST['year_published'];

        $sql = "UPDATE books SET title='$title', author='$author', genre='$genre', year_published='$year_published' WHERE id=$id";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Book updated successfully!'); window.location.href='viewbooks.php';</script>";
            exit();
        } else {
            echo "Error: " . $conn->error;
        }
    }
    ?>
    <form method="POST">
        <h2>Edit Book</h2>
        <label>Title:</label>
        <input type="text" name="title" value="<?= $book['title'] ?>" required><br>
        <label>Author:</label>
        <input type="text" name="author" value="<?= $book['author'] ?>" required><br>
        <label>Genre:</label>
        <input type="text" name="genre" value="<?= $book['genre'] ?>" required><br>
        <label>Year Published:</label>
        <input type="number" name="year_published" value="<?= $book['year_published'] ?>" required><br>
        
        <div class="btn-container">
            <input type="submit" class="update-btn" value="Update">
            <a href="viewbooks.php" class="cancel-btn">Cancel</a>
        </div>
    </form>
</body>
</html>
