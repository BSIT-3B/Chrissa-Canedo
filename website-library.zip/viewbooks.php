<?php
include 'dbconnection.php';

$sql = "SELECT * FROM books";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Book List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #060270;
            color: white;
            padding: 15px;
            font-size: 50px;
            font-weight: bold;
            text-align: center;
            width: 100%;
            margin-bottom: 20px;
        }
        table {
            width: 80%;
            margin: auto;
            border-collapse: collapse;
            background: white;
        }
        th, td {
            padding: 10px;
            border: 1px solid black;
        }
        th {
            background-color: #060270;
            color: white;
        }
        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        .edit-btn, .delete-btn {
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
            font-size: 14px;
            font-weight: bold;
			
        }
        .edit-btn {
            background-color: #040148;
            color: white;
        }
        .edit-btn:hover {
            background-color: #45a049;
        }
        .delete-btn {
            background-color: #f44336;
            color: white;
        }
        .delete-btn:hover {
            background-color: #d32f2f;
        }
        .back-btn {
            text-decoration: none;
            padding: 10px 20px;
            background-color: #a55f21;
            color: white;
            border-radius: 5px;
            display: inline-block;
            margin-top: 20px;
			background-color: #060270;
        }
        .back-btn:hover {
            background-color: #040148;
        }
    </style>
</head>
<body>

<div class="header">Book List</div>

<table>
    <tr>
        <th>Title</th>
        <th>Author</th>
        <th>Genre</th>
        <th>Year Published</th>
        <th>Action</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['title']; ?></td>
            <td><?php echo $row['author']; ?></td>
            <td><?php echo $row['genre']; ?></td>
            <td><?php echo $row['year_published']; ?></td>
            <td class="action-buttons">
                <a href="editbooks.php?id=<?php echo $row['id']; ?>" class="edit-btn">Edit</a>
                <a href="deletebooks.php?id=<?php echo $row['id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this book?');">Delete</a>
            </td>
        </tr>
    <?php } ?>
</table>


<a href="dashboard.php" class="back-btn">Back</a>

</body>
</html>
