<!DOCTYPE html>
<html>
<head>
    <title>Online Library Management System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            text-align: center;
        }
        .navbar {
            background-color: #060270;
            padding: 15px;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            gap: 15px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar button {
            padding: 10px 20px;
            border: 2px solid #007BFF;
            background: white;
            color: #007BFF;
            border-radius: 20px;
            cursor: pointer;
            font-size: 16px;
        }
        .navbar button:hover {
            background: #007BFF;
            color: white;
        }
        .search-bar {
            padding: 10px;
            border: 2px solid #ccc;
            border-radius: 20px;
            width: 250px;
            font-size: 16px;
        }
        .main-content {
            opacity: 0;
            transform: translateY(-50px);
            transition: opacity 0.9s ease-out, transform 0.9s ease-out;
        }
        .show {
            opacity: 1;
            transform: translateY(0);
        }
        .header {
            font-size: 50px;
            font-weight: bold;
            color: #060270;
            margin-top: 20px;
            text-shadow: 3px 3px 6px rgba(0, 0, 0, 0.3);
            font-family: Tahoma;
        }
        .carousel {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
        }
        .carousel img {
            width: 400px;
            height: 450px;
            object-fit: cover;
            border-radius: 5px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.2);
        }
        .dots {
            margin-top: 10px;
        }
        .dot {
            height: 10px;
            width: 10px;
            margin: 0 5px;
            background-color: #bbb;
            border-radius: 50%;
            display: inline-block;
            cursor: pointer;
        }
        .dot:hover {
            background-color: #717171;
        }
        .library-info {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            margin-top: 20px;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            margin-left: auto;
            margin-right: 950px;
        }
        .library-info img {
            width: 450px;
            height: 450px;
            object-fit: cover;
            border-radius: 5px;
        }
        .library-info1 {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            margin-top: -490px;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            margin-left: 980px;
            margin-right: auto;
        }
        .library-info1 img {
            width: 400px;
            height: 400px;
            object-fit: cover;
            border-radius: 5px;
        }
        .library-info p {
            font-size: 20px;
            text-align: left;
            color: #333;
        }
    </style>
</head>
<body onload="animatePage()">
    <div class="navbar">
        <button onclick="location.href='index.php'">Home</button>
        <button onclick="location.href='viewbooks.php'">List Books</button>
        <button onclick="location.href='addbooks.php'">Add Books</button>
        <input type="text" class="search-bar" id="searchInput" placeholder="Search..." onkeyup="searchBooks()">
        <button onclick="location.href='index.php'">Log out</button>
		
    </div>

    <div class="main-content">
        <div class="header">Online Library Management System</div>
        <div class="carousel">
            <img src="image1.jpg" alt="Library Image">
            <img src="image2.jpg" alt="Library Image">
            <img src="image3.jpg" alt="Library Image">
            <img src="image4.jpg" alt="Library Image">
        </div>
        <div class="dots">
            <span class="dot"></span>
            <span class="dot"></span>
            <span class="dot"></span>
        </div>
        <div class="library-info">
            <img src="image5.jpg" alt="Library Overview">
            <p>The Online Library Management System provides a convenient way to manage books, track borrowings, and ensure a seamless reading experience for students and faculty. With an intuitive interface and powerful search features, accessing library resources has never been easier.</p>
        </div>
        <div class="library-info1">
            <img src="image6.jpg" alt="Library Overview">
        </div>
    </div>

    <script>
        function animatePage() {
            document.querySelector('.main-content').classList.add('show');
        }
    </script>
</body>
</html>
